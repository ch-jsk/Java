import java.awt.*;
import java.applet.*;
public class Applet_Circle extends Applet
{
         @Override
 	public void paint(Graphics g)
	{
 		
 		g.setColor(Color.pink);
 		g.fillOval(70,30,300,300);
	}
}