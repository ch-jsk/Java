import java.awt.*;
import java.applet.*;
public class Simple extends Applet
{ 
	public void paint(Graphics g)
	{
		g.drawString("A simple Applet", 100, 100);
	}
}